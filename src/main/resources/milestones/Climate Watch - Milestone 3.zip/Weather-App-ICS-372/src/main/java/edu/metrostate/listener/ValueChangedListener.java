package edu.metrostate.listener;

public interface ValueChangedListener {
    public void onValueChange(int newValue);
}
